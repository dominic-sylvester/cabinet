// Isolated proof of concept: Docker exec is the local transport, not a production API.
import { execFileSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const container = 'cabinet-wiki-sample';
function text(value) {
  return `convert_from(decode('${Buffer.from(value, 'utf8').toString('base64')}', 'base64'), 'UTF8')`;
}
function sql(statement) {
  return execFileSync('docker', ['exec', '-i', container, 'psql', '-X', '-q', '-A', '-t', '-v', 'ON_ERROR_STOP=1', '-U', 'postgres', '-d', 'cabinet_wiki_sample'], {
    input: statement, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024,
  }).trim();
}
function rows(statement) {
  return JSON.parse(sql(`SELECT coalesce(json_agg(r), '[]'::json) FROM (${statement}) r;`));
}
export function initialize() {
  sql(`CREATE TABLE IF NOT EXISTS documents (
    id uuid PRIMARY KEY, path text UNIQUE NOT NULL, current_revision_id uuid
  );
  CREATE TABLE IF NOT EXISTS revisions (
    id uuid PRIMARY KEY, document_id uuid NOT NULL REFERENCES documents(id),
    sha256 text NOT NULL, raw_markdown text NOT NULL, byte_size bigint NOT NULL,
    recorded_at timestamptz NOT NULL DEFAULT now(), UNIQUE(document_id,sha256)
  );
  CREATE INDEX IF NOT EXISTS revisions_body_fts ON revisions USING gin(to_tsvector('english',raw_markdown));`);
}
export function importMarkdown(path, markdown) {
  const hash = createHash('sha256').update(markdown, 'utf8').digest('hex');
  const documentId = randomUUID();
  const revisionId = randomUUID();
  sql(`BEGIN;
    INSERT INTO documents(id,path) VALUES ('${documentId}',${text(path)}) ON CONFLICT(path) DO NOTHING;
    INSERT INTO revisions(id,document_id,sha256,raw_markdown,byte_size)
      SELECT '${revisionId}',id,'${hash}',${text(markdown)},${Buffer.byteLength(markdown)} FROM documents WHERE path=${text(path)}
      ON CONFLICT(document_id,sha256) DO NOTHING;
    UPDATE documents d SET current_revision_id=r.id FROM revisions r
      WHERE d.path=${text(path)} AND r.document_id=d.id AND r.sha256='${hash}';
    COMMIT;`);
  return rows(`SELECT d.id AS document_id,r.id AS revision_id,r.sha256,r.byte_size
    FROM documents d JOIN revisions r ON r.id=d.current_revision_id WHERE d.path=${text(path)}`)[0];
}
export function readDocument(id, revision) {
  const result = rows(`SELECT d.id AS document_id,d.path,r.id AS revision_id,r.sha256,r.raw_markdown,r.byte_size
    FROM documents d JOIN revisions r ON r.document_id=d.id AND r.id=${revision ? `${text(revision)}::uuid` : 'd.current_revision_id'}
    WHERE d.id=${text(id)}::uuid`)[0];
  if (!result) throw new Error('Document/revision not found');
  return result;
}
export function listDocuments() {
  return rows(`SELECT d.id AS document_id,d.path,r.id AS revision_id,r.sha256,r.byte_size,
    (SELECT count(*)::int FROM revisions old WHERE old.document_id=d.id) AS revision_count
    FROM documents d JOIN revisions r ON r.id=d.current_revision_id ORDER BY d.path`);
}
export function search(query) {
  return rows(`SELECT d.id AS document_id,d.path,r.id AS revision_id,r.sha256,
    ts_headline('english',r.raw_markdown,websearch_to_tsquery('english',${text(query)}),'MaxWords=60,MinWords=20') AS excerpt
    FROM documents d JOIN revisions r ON r.id=d.current_revision_id
    WHERE to_tsvector('english',r.raw_markdown) @@ websearch_to_tsquery('english',${text(query)})
    ORDER BY d.path LIMIT 20`);
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [command, ...args] = process.argv.slice(2);
  let result;
  if (command === 'init') { initialize(); result = { initialized: true }; }
  else if (command === 'import') result = importMarkdown(args[0], readFileSync(args[1], 'utf8'));
  else if (command === 'list') result = listDocuments();
  else if (command === 'search') result = search(args.join(' '));
  else if (command === 'read') result = readDocument(args[0], args[1]);
  else throw new Error('Commands: init | import <logical-path> <input-file> | list | search <query> | read <document-id> [revision-id]');
  console.log(JSON.stringify(result, null, 2));
}
