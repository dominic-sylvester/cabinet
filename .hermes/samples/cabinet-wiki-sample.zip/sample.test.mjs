import assert from 'node:assert/strict';
import test from 'node:test';
import { initialize, importMarkdown, readDocument, search, listDocuments } from './sample.mjs';

test('Postgres stores and returns full Markdown losslessly without an input file', () => {
  initialize();
  const markdown = '---\r\ntitle: Sample α\r\n---\r\n\r\n# Insurance\r\n\r\nKeep [[float]] and punctuation: \'quoted\' $wiki$ \\ exactly.\r\n';
  const imported = importMarkdown('test/lossless.md', markdown);
  assert.equal(readDocument(imported.document_id).raw_markdown, markdown);
  assert.equal(importMarkdown('test/lossless.md', markdown).revision_id, imported.revision_id);
  assert.ok(search('insurance').some(row => row.document_id === imported.document_id));
  assert.ok(listDocuments().some(row => row.document_id === imported.document_id));
});
