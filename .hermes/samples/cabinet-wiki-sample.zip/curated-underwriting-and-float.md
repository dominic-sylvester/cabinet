---
title: "Underwriting discipline and float: Berkshire's 1977, 1987 and 1997 letters"
tags:
  - postgres-sample
  - berkshire-hathaway
  - insurance
  - underwriting
  - float
sources:
  - reference: S1977
    document_id: "57a318a1-522b-4373-aa56-5ded9b7e20ae"
    revision_id: "e0e256ce-c897-4356-9331-ccade29fe813"
    sha256: "dff9ecff9adc002848e6a56f481798e7b9ff2a1edade0562ec73b3530e28206b"
    original_logical_path: "berkshire/1977 - Letter to Shareholders.md"
  - reference: S1987
    document_id: "22a659e7-acb3-47ae-9660-b7c3c84745eb"
    revision_id: "80591b42-f770-4b39-8ebc-158f97e55c52"
    sha256: "6083a69052bd9aa817a80b7ca7734b5b45a922c62455600cdf9c7448934407f8"
    original_logical_path: "berkshire/1987 - Letter to Shareholders.md"
  - reference: S1997
    document_id: "daac5ba6-308d-4aaa-a3a6-b8a2e37dfc97"
    revision_id: "30551a5b-d2a2-49b0-b944-222fc2ebdb00"
    sha256: "7bf2945b1db74751dc1bfa7111b62e136993c61d2e0a7447daad8ec8d6e3df70"
    original_logical_path: "berkshire/1997 - Letter to Shareholders.md"
---

# Underwriting discipline and float

> **Sample status:** This is a curated prototype page, not an imported raw letter. Evidence was retrieved exclusively from the isolated PostgreSQL sample through its read-only CLI. The prototype CLI is not integrated with production MCP. PostgreSQL holds the authoritative raw Markdown for this sample; this page remains a disk-based Cabinet document.

## Synthesis

**Underwriting discipline controls the price paid for investable funds.** Across these three letters, the argument develops from accepting lower premium volume to explicitly measuring float's funding cost. Float is not owned capital, and its growth alone is not proof of value.

**1977: shrink rather than underprice.** National Indemnity's strong underwriting produced both profits and funds for investment. Buffett anticipated that competition would return and rates would become inadequate. Accepting reduced volume would then require unusual discipline. Reinsurance also supplied substantial investment funds relative to premiums, but its 107.1 combined ratio was still described as unsatisfactory. Investment capacity did not erase the underwriting criticism. [S1977, lines 152-173]

**1987: premium volume and combined ratio are incomplete measures.** Berkshire described indifference to volume and pricing based on exposure rather than competitors. It could retain standby capacity instead of matching inadequate prices. Its statutory combined ratio, excluding structured settlements and financial reinsurance, worsened from 103 to 105, yet profitability improved because Berkshire used much more float. The letter's industry break-even range of 107-111 included investment income on float but excluded earnings on shareholder funds. That historical illustration is not a universal acceptable underwriting target. [S1987, lines 476-483, 566-600, 615-625]

**1997: assess funding cost and estimation risk together.** Premiums arrive before claims are paid, creating funds available for investment. Underwriting losses are the cost of that float; underwriting profits make the cost negative. The economic test is whether float costs less over time than alternative funding. But estimated loss costs can materially distort reported underwriting results. Berkshire also warned that super-catastrophe exposure could cause severe cost spikes. Ajit Jain's willingness to reject inadequately priced business connects this funding framework back to the discipline described in 1977. [S1997, lines 302-336, 390-397, 469-475]

**Curated conclusion:** Evaluate float's quantity, underwriting cost and reliability together. Refusing cheap business protects funding economics, while more float can improve overall results even when the combined ratio deteriorates. Neither observation licenses indiscriminate growth or reliance on uncertain reserves.

## Revision-bound supporting quotations

### S1977: discipline over volume

> Unusual managerial discipline will be required,
> as it runs counter to normal institutional behavior to let the
> other fellow take away business - even at foolish prices.

Lines **164-166**. Revision `e0e256ce-c897-4356-9331-ccade29fe813`; SHA-256 `dff9ecff9adc002848e6a56f481798e7b9ff2a1edade0562ec73b3530e28206b`.

### S1987: more float can offset a worse ratio

> our profitability improved materially in 1987 because we had the
> use of far more float.

Lines **620-621**. Revision `80591b42-f770-4b39-8ebc-158f97e55c52`; SHA-256 `6083a69052bd9aa817a80b7ca7734b5b45a922c62455600cdf9c7448934407f8`.

### S1997: underwriting profit makes float's cost negative

> In those years
> when we have had an underwriting profit, such as the last five, our cost
> of float has been negative. In effect, we have been paid for holding money.

Lines **334-336**. Revision `30551a5b-d2a2-49b0-b944-222fc2ebdb00`; SHA-256 `7bf2945b1db74751dc1bfa7111b62e136993c61d2e0a7447daad8ec8d6e3df70`.

## Retrieval and provenance

```sh
node /Users/domsylvester/.hermes/cache/scratch/cabinet-wiki-sample/sample.mjs search 'insurance underwriting'
node /Users/domsylvester/.hermes/cache/scratch/cabinet-wiki-sample/sample.mjs read 57a318a1-522b-4373-aa56-5ded9b7e20ae
node /Users/domsylvester/.hermes/cache/scratch/cabinet-wiki-sample/sample.mjs read 22a659e7-acb3-47ae-9660-b7c3c84745eb
node /Users/domsylvester/.hermes/cache/scratch/cabinet-wiki-sample/sample.mjs read daac5ba6-308d-4aaa-a3a6-b8a2e37dfc97
```

References resolve through the stable document IDs above, not local file URLs. Line spans are one-based and inclusive in `raw_markdown.split('\n')`; quotation endpoints may fall within a line. Quoted wording and internal line breaks are unchanged. Each retrieved raw text's UTF-8 SHA-256 was checked against its returned revision hash. A future `read` must match the cited revision and hash before reusing these coordinates. Exact database fidelity does not establish fidelity to the printed original: imported text may contain OCR or formatting defects, and no original scan was checked. No source files were consulted.
