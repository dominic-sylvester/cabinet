# Cabinet PostgreSQL wiki sample

This is an isolated proof of concept, not production Cabinet/MCP integration.

## What it contains

- Three real raw Berkshire shareholder letters (1977, 1987, 1997) stored as complete PostgreSQL TEXT, with SHA-256 and revision IDs.
- `sample.mjs`: dependency-free Node CLI using Docker exec/psql as the transport. No database credentials, network service or original source mounts are needed.
- `sample.test.mjs`: a real PostgreSQL lossless Markdown/idempotency/search test, with one clearly labeled synthetic fixture.
- `import-manifest.json`: real document IDs, revision IDs, hashes and verified import outcomes.
- `sample.dump`: PostgreSQL custom-format backup of the sample database (includes the test fixture).
- A curated Cabinet Markdown page and verification report, added after curation completes.

## Existing instance

Container: `cabinet-wiki-sample`. No published ports, no network, 256 MiB RAM cap, one CPU, restart policy `no`. PostgreSQL data is in its Docker-managed volume, not scratch storage. No other database/container is changed. Local trust authentication is acceptable only because this isolated sample has no network or published port and is reached using Docker exec; it is not a production configuration.

Run from this directory:

```sh
node sample.mjs list
node sample.mjs search 'insurance underwriting'
node sample.mjs read <document_id> [revision_id]
node --test sample.test.mjs
```

These commands read wiki content from PostgreSQL; they never open the original wiki files. The container has no host source bind mount. Original sources are unchanged. Imports were compared byte-for-byte and re-imported to check revision idempotency.

## Restore into a separate sample container

Create an isolated target with a different name, then restore using stdin. The CLI is pinned to `cabinet-wiki-sample`; change that constant in your own copy if you want to query the restored target. Never restore over an existing application database.

```sh
docker run -d --name cabinet-wiki-sample-restored --network none --memory 256m --cpus 1 --restart no -e POSTGRES_HOST_AUTH_METHOD=trust -e POSTGRES_DB=cabinet_wiki_sample postgres:16
# Wait for pg_isready before restoring:
docker exec cabinet-wiki-sample-restored pg_isready -U postgres -d cabinet_wiki_sample
docker exec -i cabinet-wiki-sample-restored pg_restore -U postgres -d cabinet_wiki_sample --exit-on-error < sample.dump
```

No original wiki files are needed for restore/read. This sample has no multi-room access controls, production MCP bridge, app configuration screen, automated ingest, source editing API or analytical fact extraction. Curated file provenance uses explicit document/revision IDs and hashes, not an installed `knowledge://` resolver.

Stopping the sample is reversible (`docker stop cabinet-wiki-sample`). Do not remove its container/volume until its dump has been verified and you decide to retire it.
